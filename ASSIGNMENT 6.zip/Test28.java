import java.util.Scanner;
class Test28
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a string:");
        String s=sc.nextLine();
        if(s.length()%2==0)
        {
            System.out.println("Result: "+s.substring(0,s.length()/2));
        }
        else
        {
            System.out.println("Result:");
        }
        sc.close();
    }
}